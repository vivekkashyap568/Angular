import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-car',
  templateUrl: './car.component.html',
  styleUrls: ['./car.component.css']
})
export class CarComponent implements OnInit {

  _carId:any;
  constructor(private _act_route: ActivatedRoute) { }

  ngOnInit(): void {

    this._carId = this._act_route.snapshot.params['id']
  }

}
