import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { CarsComponent } from './cars/cars.component';
import { AboutComponent } from './about/about.component';
import { CarComponent } from './car/car.component';
import { FeatureComponent } from './feature/feature.component';
import { SpecificationComponent } from './specification/specification.component';

const routes: Routes = [
  {path: 'cars', component:CarsComponent},
  {path: 'about', component:AboutComponent},
  {path: 'car/:id', component:CarComponent,
    children:[
          {path: 'feature', component:FeatureComponent},
          {path: 'specs', component:SpecificationComponent},
          {path: '', redirectTo:'feature',pathMatch:'full'}
        ]

    },
  {path: '', redirectTo:'about',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [CarsComponent,  AboutComponent,  CarComponent,  FeatureComponent,  SpecificationComponent]