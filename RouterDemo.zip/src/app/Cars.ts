export const Cars = [
    {
        Id:1,
        Model: "Mustang GT 500",
        Make: "Ford",
        Year: "2021",
        Price: "75 Lakhs"
    },
    {
        Id:2,
        Model: "Challenger SRT",
        Make: "Dodge",
        Year: "2020",
        Price: "65 Lakhs"
    },
    {
        Id:3,
        Model: "Wrangler Rubicon",
        Make: "Jeep",
        Year: "2021",
        Price: "57 Lakhs"
    },
    {
        Id:4,
        Model: "Evoque",
        Make: "Rangerover",
        Year: "2020",
        Price: "48 Lakhs"
    },
    {
        Id:5,
        Model: "Cayenne",
        Make: "Porsche",
        Year: "2020",
        Price: "60 Lakhs"
    }
];