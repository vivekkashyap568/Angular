import { Component, OnInit } from '@angular/core';
import {Cars} from '../Cars';
@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
export class CarsComponent implements OnInit {
  _cars =Cars; 

  constructor() { }

  ngOnInit(): void {
  }

}
